var searchData=
[
  ['quality_20of_20service_607',['Quality of service',['../qos.html',1,'']]]
];
